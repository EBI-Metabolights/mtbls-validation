package onto

ontology_set := {onto |
	some onto, detail in data.metabolights.validation.v2.templates.ontologySourceReferenceTemplates
}

x_data := [
	"OBI",
	"EFO",
	"CHMO",
	"NCIT",
	"NCBITaxon",
	"MS",
	"BTO",
	"CHEBI",
	"UO",
	"MESH",
	"BAO",
	"OMIT",
	"GO",
	"ENVO",
	"MSIO",
	"PO",
	"MONDO",
	"UBERON",
	"SNOMED",
	"CL",
	"CLO",
	"MI",
	"EDAM",
	"HP",
	"MP",
]

default_set := {x | some x in x_data}

diff := default_set - ontology_set
